/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package practica1;
import java.io.IOException;
//import java.io.InputStreamReader;

/**
 *
 * @author Ignacio Poza i Blanca Ruiz
 */
public class EditableBufferedReader {
    //static final int RIGHT
    //static final int LEFT
    //static final int HOME
    //static final int END
    //static final int INS
    //static final int DEL
    //static final int BACKSPACE

    
    public void unsetRaw() throws IOException {
    //passa la consola de mode raw a mode cooked
        String [] cmd = {"/bin/sh", "-c", "stty raw </dev/tty"};
        try {
        Runtime.getRuntime().exec(cmd).waitFor();
        }catch (IOException | InterruptedException ex) {
            System.out.println("Error ");
        }
    }
    
    public void setRaw() throws IOException {
    //passa la consola de mode cooked a mode raw
        String [] cmd = {"/bin/sh", "-c", "stty raw </dev/tty"};
        try {
        Runtime.getRuntime().exec(cmd).waitFor();  
        }catch (Exception ex) {
            System.out.println("Error");
        }   
    }
    
    //public int read() {
    //llegeix el següent caràcter o la següent tecla de cursor
    //int caracter = 0;
    //hem de fer un switch distinguint els diferents casos amb la resposta desitjada
    //declarar les tecles al principi del fitxer amb el numero corresponent
        //    switch(caracter) {
                //case EditableBufferedReader.RIGHT
                
               
          //  }
    
        
   // }
   
   // public int readLine() {
    //llegeix la línia amb possibilitat d'editar-la
    
    //}
}
