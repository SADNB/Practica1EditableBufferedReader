import java.io.*;
import java.util.*;

public class Console implements Observer {
	// \033 és l'equivalent a ^[
    static final String RIGHT = "\033[C";
    static final String LEFT = "\033[D";
    static final String INSERT = "\033[4h";
    static final String BACKSPACE = "\b";
    static final String DELETE = "\033[P";
    static final String HOME = "\033[1~";
    static final String END = "\033[4~";
    static final String ESPAI = "\033[ ";
    static final String BLANK_SPACE = "\033[@";
    
    //seqüències d'scape (definides a partir de 2001 per assegurar)
	static final int SEC_RIGHT = 2001;
	static final int SEC_LEFT = 2002;
	static final int SEC_HOME = 2003;
	static final int SEC_END = 2004;
	static final int SEC_INSERT = 2005;
	static final int SEC_DELETE = 2006;
	static final int SEC_CHAR = 2007;
	static final int SEC_BACKSPACE = 127;

   Line line;

   public Console(Line l){
   	this.line=l;
   }

   public void update(Observable ob, Object o){

	int comanda = (int)o;

	switch(comanda){
		case SEC_RIGHT:
		   System.out.print(RIGHT);
		   break;
		case SEC_LEFT:
		   System.out.print(LEFT);
		   break;
		case SEC_HOME:
		   this.updateCursor(this.line.getPos());
		   System.out.print(HOME);
		   break;
		case SEC_END:
		   this.updateCursor(this.line.getPos());
		   System.out.print(END);
		   break;	
		case SEC_INSERT:
		   System.out.print(INSERT);
		   break;
		case SEC_DELETE:
		   System.out.print(DELETE);
		   break;
		case SEC_CHAR:
		    boolean aux = this.line.getInsert();	//ens informa de l'estat
								//hem hagut de crear un boolean a Line.java de retorni el mode actual per a que sigui compatible amb aux
		   if(aux){					//si estem mode inserció
		   	System.out.print(this.line.getLastChar());
		   } else {					//si estem mode sobreescriptura
		   	System.out.print(ESPAI);
			System.out.print(this.line.getLastChar());
		   }
		   break;
		case SEC_BACKSPACE:
		   System.out.print(BACKSPACE);
		   break;
	}
   }

public void updateCursor(int cursorPos){
        int aux = cursorPos + 1;
        System.out.print("\033["+aux+"G");
    }


}
